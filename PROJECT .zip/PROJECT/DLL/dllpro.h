__declspec(dllexport) void test (int a[]);
