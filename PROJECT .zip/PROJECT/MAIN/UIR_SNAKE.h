/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_COMMANDBUTTON              2       /* control type: command, callback function: PLAY */
#define  PANEL_QUITBUTTON                 3       /* control type: command, callback function: QuitCallback */
#define  PANEL_COMMANDBUTTON_2            4       /* control type: command, callback function: TowSnakes */
#define  PANEL_PICTURE                    5       /* control type: picture, callback function: (none) */
#define  PANEL_COMMANDBUTTON_3            6       /* control type: command, callback function: instructions */

#define  PANEL_2                          2
#define  PANEL_2_COMMANDBUTTON            2       /* control type: command, callback function: KeyCallback */
#define  PANEL_2_LED                      3       /* control type: LED, callback function: (none) */
#define  PANEL_2_CANVAS                   4       /* control type: canvas, callback function: (none) */
#define  PANEL_2_NUMERIC                  5       /* control type: numeric, callback function: (none) */
#define  PANEL_2_NUMERIC_2                6       /* control type: numeric, callback function: (none) */

#define  PANEL_3                          3
#define  PANEL_3_COMMANDBUTTON_2          2       /* control type: command, callback function: QuitCallback */
#define  PANEL_3_NUMERIC11                3       /* control type: numeric, callback function: (none) */
#define  PANEL_3_NUMERIC22                4       /* control type: numeric, callback function: (none) */
#define  PANEL_3_OKBUTTON                 5       /* control type: command, callback function: menufunc */
#define  PANEL_3_STRING                   6       /* control type: string, callback function: (none) */
#define  PANEL_3_TABLE                    7       /* control type: table, callback function: (none) */
#define  PANEL_3_PICTURE                  8       /* control type: picture, callback function: (none) */


     /* Control Arrays: */

#define  CTRLARRAY                        1

     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK instructions(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK KeyCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK menufunc(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLAY(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK QuitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TowSnakes(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
