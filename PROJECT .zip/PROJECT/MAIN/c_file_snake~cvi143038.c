#include "toolbox.h"
#include <utility.h>
#include <userint.h>
#include "UIR_SNAKE.h"
#include <ansi_c.h>
#include <dllpro.h>
#include <stdlib.h>
void Apple ();//int Arrx[],int Arry[],int index);
void SnakeMove();
int CVICALLBACK KeyCallback (int panel, int control, int event,
						void *callbackData, int eventData1, int eventData2);
int CVICALLBACK PLAY (int panel, int control, int event,
					  void *callbackData, int eventData1, int eventData2);
int CVICALLBACK QuitCallback (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2);

static int panelHandle;
static int panelHandle2;
static int panelHandle3; 
static double cnt=0.0,cnt1=0.0;
static CmtThreadFunctionID f1ID;
static CmtThreadFunctionID f2ID;  
static CmtThreadPoolHandle p1Handle;
int appleSize = 10;
int snakeSize = 10;
int MinimunX=0, MaximunX= 0, MinimunY=0, MaximunY=0,NumX=0,NumY=0,SizeOfSnakePos=0,EatAnApple=0;SizeOfSnakePos2=0,numberOfSnakes=1;
enum  snakedirection{NONE,UP,DOWN,LEFT,RIGHT,QUIT};
enum snakedirection Direction = RIGHT;
enum snakedirection Direction2 = RIGHT; 
//struct CircleOnScreen{

//	int x;
//	int y;
//	int size;
//} ;
struct SnakePos {
	int x;
	int y;
	enum snakedirection direct;
};	 
static struct SnakePos snakePositions[1000];
static struct SnakePos snakePositions2[1000];
struct SnakePos tempPos;
struct SnakePos tempPos2; 

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "UIR_SNAKE.uir", PANEL)) < 0)
		return -1;
	if ((panelHandle2 = LoadPanel (0, "UIR_SNAKE.uir", PANEL_2)) < 0)
		return -1;
	if ((panelHandle3 = LoadPanel (0, "UIR_SNAKE.uir", PANEL_3)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle); 
	DiscardPanel (panelHandle2);
	DiscardPanel (panelHandle3);
	CmtDiscardThreadPool (p1Handle);
	return 0;
}

void DrawApple() 
{
    SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_MODE, VAL_XOR_MODE);
    SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_FILL_COLOR, VAL_DK_RED);
    SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_COLOR, VAL_DK_RED);
    CanvasDrawRect (panelHandle2, PANEL_2_CANVAS, MakeRect (NumY,NumX, appleSize,appleSize), VAL_DRAW_FRAME_AND_INTERIOR);
	//CanvasDrawRoundedRect (panelHandle2, PANEL_2_CANVAS, MakeRect (NumY,NumX, appleSize,appleSize), 5, 5, VAL_DRAW_FRAME_AND_INTERIOR);
	
}

int AddToTheBegining(struct SnakePos newElement, struct SnakePos snakeArr[], int sizeOfSnake) 
{
	int i;
    for(i=sizeOfSnake+1;i>0;i--)
    {
        snakeArr[i]=snakeArr[i-1];
    }
    snakeArr[0]=newElement;	
    return	(sizeOfSnake+1);
}

int CheckLose()
{
		if (tempPos.x > MaximunX || tempPos.x < MinimunX ||
		    tempPos.y > MaximunY || tempPos.y < MinimunY)
		{
			  return 1;
		}
		
		for(int i=0; i<=SizeOfSnakePos;i++)
	    {
		    if (snakePositions[i].y == tempPos.y && snakePositions[i].x== tempPos.x) 
			{												
				return 2;
			}
			else if ( numberOfSnakes==2 && snakePositions[i].y == tempPos2.y && snakePositions[i].x== tempPos2.x ) 
			{												
				return 3;
			}
		}
		if (numberOfSnakes==2 &&(tempPos2.x > MaximunX || tempPos2.x < MinimunX ||
		    tempPos2.y > MaximunY || tempPos2.y < MinimunY))
		{
			  return 4;
		}
		
		for(int i=0; i<=SizeOfSnakePos2;i++)
	    {
		   if (snakePositions2[i].y == tempPos.y && snakePositions2[i].x== tempPos.x) 
			{												
				return 5;
			}
			else if (numberOfSnakes==2 && snakePositions2[i].y == tempPos2.y && snakePositions2[i].x== tempPos2.x) 
			{												
				return 6;
			}
		}
		
	
		return 0;
}
struct SnakePos UpdateDirect (enum snakedirection dir,struct SnakePos headOfSnake )
{
	 if(dir == UP)// check if what we pressed is up
		{
			headOfSnake.y-=appleSize;
		
		}
		else if(dir == DOWN)// check if what we pressed is down 
		{
 			  headOfSnake.y+=appleSize;
			
		}
		else if(dir == LEFT)// check if what we pressed is left
		{
			headOfSnake.x-=appleSize;
		
		}
		else if(dir == RIGHT)// check if what we pressed is right 
		{				 
			
			headOfSnake.x+=appleSize;
		
		}
		return headOfSnake;
}
void SnakeMove()
{
				
  while(Direction!=QUIT)
  {
	  Delay(0.16);
	  if(Direction!=QUIT)
	  {
	  CanvasClear (panelHandle2, PANEL_2_CANVAS, VAL_ENTIRE_OBJECT);
	  
	  
		  DrawApple();  
	      tempPos = snakePositions[0];
		  tempPos2 = snakePositions2[0];
		 tempPos=UpdateDirect(Direction , tempPos); 
	     tempPos2=UpdateDirect(Direction2 , tempPos2);
	  }
												
		if (CheckLose() !=0)
		{
			Direction=QUIT;
		}
		else
		{
			SizeOfSnakePos = AddToTheBegining(tempPos,snakePositions,SizeOfSnakePos );
			if(numberOfSnakes==2) 
			{
				SizeOfSnakePos2 = AddToTheBegining(tempPos2,snakePositions2,SizeOfSnakePos2 );
			}
		
		
			if(snakePositions[0].x == NumX && snakePositions[0].y == NumY )
			{//the first snake ate an apple - so we need to make a new apple
		  
			    // Create new apple on the canvas
				Apple();//NULL,NULL,0);
				SizeOfSnakePos2--;
				cnt++;
				SetCtrlVal (panelHandle2, PANEL_2_NUMERIC,cnt);
				
			}
			else if (numberOfSnakes==2 && snakePositions2[0].x == NumX && snakePositions2[0].y == NumY)
			{//the second snake ate an apple - so we need to make a new apple
					Apple();//NULL,NULL,0); 
					SizeOfSnakePos--; 
					cnt1++;
				SetCtrlVal (panelHandle2, PANEL_2_NUMERIC_2, cnt1);

			}
			else
			{
				SizeOfSnakePos--;
				SizeOfSnakePos2--; 
			}
		
			SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_MODE, VAL_COPY_MODE );
		    SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_FILL_COLOR, VAL_DK_RED);
			SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_COLOR, VAL_DK_RED);
			
			for(int i=0; i<=SizeOfSnakePos;i++)
		    {		  
				
			    CanvasDrawRect (panelHandle2, PANEL_2_CANVAS, MakeRect (snakePositions[i].y,snakePositions[i].x,snakeSize,snakeSize), VAL_DRAW_FRAME_AND_INTERIOR);
			}
			if(numberOfSnakes==2)
			{
				
				SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_MODE, VAL_COPY_MODE );
			    SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_FILL_COLOR, VAL_DK_BLUE);
				SetCtrlAttribute (panelHandle2, PANEL_2_CANVAS, ATTR_PEN_COLOR, VAL_DK_BLUE);
			
				for(int i=0; i<=SizeOfSnakePos2;i++)
		  	    {
			   		 CanvasDrawRect (panelHandle2, PANEL_2_CANVAS, MakeRect (snakePositions2[i].y,snakePositions2[i].x, snakeSize,snakeSize), VAL_DRAW_FRAME_AND_INTERIOR);
				}
			
			}
		}
	  
   }
	 
}

 int CVICALLBACK KeyCallback (int panel, int control, int event,
						void *callbackData, int eventData1, int eventData2)
{
	int  virtual=0;
	int keyPressed=0;
	 

	if (event == EVENT_KEYPRESS) 
	{
		if(!KeyPressEventIsLeadByte (eventData2))
		{
		virtual = GetKeyPressEventVirtualKey (eventData2); // bring back the number of what we pressed
		keyPressed = GetKeyPressEventCharacter(eventData2);
		}
		if(virtual==768) // if we prassed Esc
		{
			Direction=QUIT; 
		}
		if(virtual==VAL_UP_ARROW_VKEY && Direction != DOWN)// check if what we pressed is up
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 1);
			Direction = UP;
		}
		else if(virtual==VAL_DOWN_ARROW_VKEY && Direction != UP)// check if what we pressed is down 
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 0);
			Direction = DOWN;  
		}
		else if(virtual==VAL_LEFT_ARROW_VKEY && Direction != RIGHT)// check if what we pressed is left
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 1);
			Direction = LEFT;  
		}
		else if(virtual==VAL_RIGHT_ARROW_VKEY && Direction != LEFT)// check if what we pressed is right 
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 0);
			Direction = RIGHT;  
		}
		else if((keyPressed== 83 ||keyPressed== 115)  && Direction2 != UP)// check if what we pressed is down 
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 0);
			Direction2 = DOWN;  
		}
		else if((keyPressed== 119 ||keyPressed== 87) && Direction2 != DOWN)// check if what we pressed is down 
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 0);
			Direction2 = UP;  
		}
		else if((keyPressed== 68 ||keyPressed== 100) && Direction2 != LEFT)// check if what we pressed is left
		{	  
			SetCtrlVal (panelHandle2, PANEL_2_LED, 1);
			Direction2 = RIGHT;  
		}
		else if((keyPressed== 65 ||keyPressed== 97) && Direction2 != RIGHT)// check if what we pressed is right 
		{
			SetCtrlVal (panelHandle2, PANEL_2_LED, 0);
			Direction2 = LEFT;  
		}
	}
	
    return 0;
}

void InitSnakePosition()
{   if(numberOfSnakes==1)
	{
		snakePositions[1].x=0;
		snakePositions[1].y= MaximunY/2/10*10;
		snakePositions[0].x=0 + appleSize;
		snakePositions[0].y= MaximunY/2/10*10;
		SizeOfSnakePos = 1;
	}
	else
	{
		snakePositions[1].x=0;
		snakePositions[1].y= (MaximunY/2/10*10)-20;
		snakePositions[0].x=0 + appleSize;
		snakePositions[0].y= (MaximunY/2/10*10)-20;
		SizeOfSnakePos = 1;
	}
}
void InitSnakePosition2()
{
	snakePositions2[1].x=0;
	snakePositions2[1].y= (MaximunY/2/10*10)+20;
	snakePositions2[0].x=0 + appleSize;
	snakePositions2[0].y= (MaximunY/2/10*10)+20;
	SizeOfSnakePos2 = 1;
}
int CVICALLBACK PLAY (int panel, int control, int event,
					  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			DisplayPanel (panelHandle2);
			GetCtrlAttribute( panelHandle2,  PANEL_2_CANVAS,ATTR_WIDTH , &MaximunX);  //Get the size of the canvas 
			GetCtrlAttribute( panelHandle2,  PANEL_2_CANVAS,ATTR_HEIGHT  ,&MaximunY); //Get the size of the canvas
			InitSnakePosition();
			InitSnakePosition2();
			Apple(NULL,NULL,0);   
			CmtNewThreadPool (2, &p1Handle);  // when you start the game it creat new threadpool
			CmtScheduleThreadPoolFunction (p1Handle, KeyCallback, NULL, &f1ID);
			CmtScheduleThreadPoolFunction (p1Handle, SnakeMove, NULL, &f2ID);

		
			break;
	}
	return 0;
}



int CVICALLBACK QuitCallback (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
	{
		case EVENT_COMMIT:
			Direction=QUIT;
				   QuitUserInterface (0);
			break;
	}
	return 0;
}

void Apple ()//int Arrx[],int Arry[],int index)
{
	int flag=0;

	while (flag==0)
	{	   
		NumX = Random( MinimunX , MaximunX);
			NumX = NumX/10*10;
			NumY = Random( MinimunY, MaximunY);
			NumY = NumY/10*10;  
			
		for(int i=0; i<=SizeOfSnakePos; i++)
		{
			
			if(snakePositions[0].x != NumX && snakePositions[0].y != NumY)  
			{
				flag=1;
				break;
			}
		}
		if(numberOfSnakes==2)
		{
			for(int i=0; i<=SizeOfSnakePos2; i++)
			{
			
				if(snakePositions2[0].x != NumX && snakePositions2[0].y != NumY)  
				{
					flag=1;
					break;
				}
			}
		}
	}
}

int CVICALLBACK TowSnakes (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
					numberOfSnakes=2;
					PLAY ( panel,  control,  event,
						    callbackData,  eventData1,  eventData2);
			break;
	}
	return 0;
}

int CVICALLBACK instructions (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			 MessagePopup("INSTRUCTIONS","1PLAYER:\n"
						  "Use the arrow keys to control your snake.Eat as many apples as you can to grow as long as possible. But don't hit the wall, or eat your tail!\n"
						  "2PLAYERS:\n"
						  "Use |A or a=left|,|D or d=right|,|W or w =up|,|S or s =down)|\n" 
						  "RESULTS:\n"
						  "For 1 player game:\n the result is how much you eat apples but the result will decrease depend on how you lose:\n"
						  "1.Eat you tail=-10\n "
						  "2.Hit the wall=-7\n"
						  "For 2 players:\n the result is how much you eat apples but the result will decrease depend on how you lose:\n"
						  "1.Eat you tail=-10\n "
						  "2.Hit the wall=-7\n"
						  "3.Hit 2player=-12.");
      

			break;
	}
	return 0;
}
